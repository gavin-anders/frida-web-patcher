//
//  AppDelegate.h
//  sampleapp
//
//  Created by Gavin on 19/08/2020.
//  Copyright © 2020 nccgroup. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

