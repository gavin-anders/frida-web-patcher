//
//  ViewController.h
//  sampleapp
//
//  Created by Gavin on 19/08/2020.
//  Copyright © 2020 nccgroup. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

