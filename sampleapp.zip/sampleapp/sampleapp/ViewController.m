//
//  ViewController.m
//  sampleapp
//
//  Created by Gavin on 19/08/2020.
//  Copyright © 2020 nccgroup. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


@end
